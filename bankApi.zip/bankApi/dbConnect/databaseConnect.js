const mongoose = require("mongoose");
const databaseConnect = async () => {
  try {
    const connect = mongoose.connect(process.env.MONGO_URL);
    console.log("successfully connected to the database");
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
};
module.exports = databaseConnect;
