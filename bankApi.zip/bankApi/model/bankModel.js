const mongoose = require("mongoose");
const bankSchema = mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please enter name"],
  },
  email: {
    type: String,
    required: [true, "Please enter email"],
    unique: true,
  },
  contact: {
    type: Number,
    required: [true, "Please enter contact number"],
  },
  balance: {
    type: String,
    required: [true, "Please enter balance"],
  },
});
module.exports = mongoose.model("User", bankSchema);
