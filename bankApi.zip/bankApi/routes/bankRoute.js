const express = require("express");
const router = express.Router();
const {
  postUser,
  getUser,
  getUserById,
  editUser,
  deleteUser,
} = require("../controller/bankController");
router.get("/get/", getUser);
router.post("/post/", postUser);
router.get("/get/:id", getUserById);
router.put("/edit/:id", editUser);
router.delete("/delete/:id", deleteUser);
module.exports = router;
