const User = require("../model/bankModel");
const asyncHandler = require("express-async-handler");

//controller for getting all user
const getUser = asyncHandler(async (req, res) => {
  const user = await User.find({});
  res.status(200).json(user);
});

// controller for posting new user
const postUser = asyncHandler(async (req, res) => {
  const { name, email, contact, balance } = req.body;
  if (!name || !email || !contact || !balance) {
    res.status(404);
    throw new Error("please enter all the data properly");
  }
  const user = await User.create({
    name,
    email,
    contact,
    balance,
  });
  console.log("user has successfully added");
  if (user) {
    res.status(200).json({
      _id: user.id,
      email: user.email,
    });
  } else {
    res.status(400);
    throw new Error(
      "user was not created an error occured while creating the user"
    );
  }
});

//get user by id controller
const getUserById = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(400);
    throw new Error("NO user found please enter correct id");
  }
  res.status(200).json(user);
});

//edit the user details
const editUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(400);
    throw new Error("User not found please enter correct id");
  }
  const updateUser = await User.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.status(200).json(updateUser);
});

//delete the user
const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    res.status(400);
    throw new Error("The user doesnot exist please provide correct id");
  }
  res.status(200).json(user);
});
module.exports = { postUser, getUser, getUserById, editUser, deleteUser };
