const express = require("express");
const dotenv = require("dotenv").config();
const databaseConnect = require("./dbConnect/databaseConnect");
databaseConnect();
const port = process.env.PORT;
const app = express();
app.use(express.json());
app.use("/api/bank/", require("./routes/bankRoute"));
app.listen(port, (result, err) => {
  if (err) {
    console.log(err);
  }
  console.log(`server is running in port: ${port} `);
});
